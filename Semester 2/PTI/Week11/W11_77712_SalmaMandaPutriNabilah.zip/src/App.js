import "./styles.css";

import React, {useState} from "react";


function App() {
  const [count, setCount] = useState(0);
  const [time, setTime] = useState('TIME');

  function increase () {
    setCount(count + 1);
  }

  function decrease () {
    setCount(count - 1);
  }

  function currTime() {
    setTime(new Date().toLocaleTimeString());
    console.log(setTime);
  }

  return(
    <div className='App'>
      <div className='container'>
        <div className='Head'>
          <h1>{count}</h1>
        </div>
        <div className='btnCounter'>
          <button style={{width: "30px", height: "30px"}} onClick={increase}>+</button>
          <button style={{width: "30px", height: "30px"}} onClick={decrease}>-</button>
        </div>
        <div className='Head'>
          <h1>{time}</h1>
        </div>
        <div className='btnTime'>
          <button style={{padding: "0.5em"}}onClick={currTime}>Get Time</button>
        </div>
      </div>
    </div>
  );
}

export default App;

