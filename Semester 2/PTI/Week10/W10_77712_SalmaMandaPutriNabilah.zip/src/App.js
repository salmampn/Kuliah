import React from "react";
import Card from "./component/Card";
import library from "./emojipedia";
import "./styles.css";

const createCard = (library) => {
  return (
    <Card
      key={library.id}
      emoji={library.emoji}
      name={library.name}
      description={library.describe}
    />
  );
};

const App = () => {
  return (
    <div className="App">
      <div className="Judul">
        <h1>emojipedia</h1>
      </div>
      <div className="bungkusCard">{library.map(createCard)}</div>
    </div>
  );
};

export default App;
