import React from "react";

const Card = ({ emoji, name, description }) => {
  return (
    <div className="Card">
      <div className="CardEmoji">
        <div className="emoji">
          <h1>{emoji}</h1>
        </div>
        <div className="name">
          <h2>{name}</h2>
        </div>
        <div className="detail">
          <p>{description}</p>
        </div>
      </div>
    </div>
  );
};

export default Card;
