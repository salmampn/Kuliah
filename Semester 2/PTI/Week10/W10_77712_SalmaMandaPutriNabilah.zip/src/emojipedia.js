const emojipedia = [
  {
    id: 1,
    emoji: "😎",
    name: "Smiling Face with Sunglasses",
    describe:
      "A yellow face with a broad, closed smile wearing black sunglasses, as if a pair of classic Wayfarers. Often used to convey the slang sense of cool. May also express a confident, carefree attitude or that something is excellent."
  },
  {
    id: 2,
    emoji: "🥐",
    name: "Croissant",
    describe:
      "The flaky, golden-brown crescent of a croissant, a breakfast pastry associated with France and Austria."
  },
  {
    id: 3,
    emoji: "🤯",
    name: "Exploding Head",
    describe:
      "A yellow face with an open mouth, the top of its head exploding in the shape of a brain-like mushroom cloud. A visual form of the expression mind blown, it may represent such emotions as shock, awe, amazement, and disbelief."
  },
  {
    id: 4,
    emoji: "🙄",
    name: "Face with Rolling Eyes",
    describe:
      "A yellow face with a small, closed mouth, flat or frowning, rolling its large, white eyes upwards. As with the gesture of an eye-roll, commonly conveys moderate disdain, disapproval, frustration, or boredom. Tone varies, including playful, sassy, resentful, and sarcastic, as if saying Yeah, whatever."
  },
  {
    id: 5,
    emoji: "🐇",
    name: "Rabbit",
    describe:
      "A rabbit, a hoppy mammal with long ears. Depicted as a white, gray, or brown rabbit in full profile facing left with pink ears and a short tail, sitting on its long, hind legs or on all fours."
  },
  {
    id: 6,
    emoji: "😒",
    name: "Unamused Face",
    describe:
      "A yellow face with slightly raised eyebrows, a frown, and eyes looking to the side. May convey a variety of negative emotions, including irritation, displeasure, grumpiness, and skepticism, as if giving the side-eye."
  }
];

export default emojipedia;
