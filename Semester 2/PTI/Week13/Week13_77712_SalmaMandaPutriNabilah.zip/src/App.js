import React, { useEffect, useState } from "react";
import axios from "axios";

function App() {
  const [movie, setMovie] = useState();
  const url =
    "https://api.themoviedb.org/3/movie/top_rated?api_key=c0b7638a313abe154a36bee69efe34b4&language=en-US&page=1'";

  useEffect(() => {
    axios.get(url).then((response) => {
      const api = response.data.results;
      console.log(api);
      setMovie(
        api.map((topMovie) => (
          <div key={topMovie.id} style={styles.movieContainer}>
            <h1 style={styles.movieTitle}>{topMovie.title}</h1>
            <p style={styles.movieOverview}>{topMovie.overview}</p>
            <hr style={styles.movieSeparator} />
          </div>
        ))
      );
    });
  }, []);

  return <div style={styles.container}>{movie}</div>;
}

const styles = {
  container: {
    maxWidth: "960px",
    margin: "0 auto",
    padding: "20px",
    fontFamily: "Arial, sans-serif",
    backgroundColor: "#f2f2f2",
    color: "#333"
  },
  movieContainer: {
    marginBottom: "20px"
  },
  movieTitle: {
    fontSize: "24px",
    fontWeight: "bold"
  },
  movieOverview: {
    fontSize: "16px",
    lineHeight: "1.5",
    marginBottom: "10px"
  },
  movieSeparator: {
    margin: "10px 0",
    border: "none",
    borderBottom: "2px solid #333"
  }
};

export default App;
